/**
 * G06-NPC Notes (AFT NPC Notes): journal associations, independent of Actor ownership.
 * Existing Journal associations and permissions are never rewritten by an upgrade.
 */
export const MODULE_ID = "player-npc-notes";
export const JOURNAL_FLAG = "noteLink";
export const FOLDER_FLAG = "managedFolder";
export const SCHEMA = 1;

const inflight = new Map();

export function subjectUuidForActor(actor) {
  if (!actor || actor.documentName !== "Actor") return null;
  if (actor.token && !actor.token.actorLink) return actor.token.uuid ?? null;
  return actor.uuid ?? null;
}

/** Identifies a linked Actor across scenes, or one particular unlinked Token. */
export function subjectUuidForToken(token) {
  const doc = token?.document?.documentName === "Token" ? token.document : token;
  if (doc?.documentName !== "Token" || typeof doc.uuid !== "string") return null;
  if (doc.actorLink) {
    if (!/^[A-Za-z0-9]+$/.test(doc.actorId ?? "")) return null;
    return `Actor.${doc.actorId}`;
  }
  return doc.uuid;
}

export async function resolveSubject(subjectUuid, lookup = globalThis.fromUuid) {
  if (typeof subjectUuid !== "string" || subjectUuid.length > 256) return null;
  if (!/^(Actor\.[A-Za-z0-9]+|Scene\.[A-Za-z0-9]+\.Token\.[A-Za-z0-9]+)$/.test(subjectUuid)) return null;
  const doc = await lookup(subjectUuid);
  if (doc?.documentName === "Actor" && !doc.inCompendium) {
    return { actor: doc, subjectUuid };
  }
  if (doc?.documentName === "Token" && doc.parent?.documentName === "Scene" && doc.actor) {
    return { actor: doc.actor, subjectUuid, sceneId: doc.parent.id };
  }
  return null;
}

/** Previous sheet-based workflow remains available for Actors with Limited access. */
export function playerMayNote(actor, user) {
  return Boolean(actor && user && actor.testUserPermission?.(user, "LIMITED"));
}

export function journalKey(subjectUuid, scope, userId = "") {
  return `${subjectUuid}|${scope}|${scope === "personal" ? userId : ""}`;
}

export function isValidScope(scope) {
  return scope === "shared" || scope === "personal";
}

export function journalLink(entry) {
  return entry?.getFlag?.(MODULE_ID, JOURNAL_FLAG) ?? null;
}

export function findJournal(journals, subjectUuid, scope, userId) {
  if (!isValidScope(scope)) return null;
  return Array.from(journals).find(entry => {
    const link = journalLink(entry);
    return link?.schema === SCHEMA && link.subjectUuid === subjectUuid &&
      link.scope === scope && (scope === "shared" || link.userId === userId);
  }) ?? null;
}

/**
 * Journals have their own permissions. New party notes are explicitly shared
 * with the world players; personal notes only with their author and GMs.
 * These defaults apply at CREATE time only: preexisting Journal permissions
 * are always left untouched, including journals made by prior versions.
 */
export function buildOwnership(_actor, scope, userId, users, levels) {
  const ownership = { default: levels.NONE };
  if (scope === "personal") {
    const user = Array.from(users).find(u => u.id === userId);
    if (!user) throw new Error("The requested player is no longer in this world.");
    if (!user.isGM) ownership[user.id] = levels.OWNER;
  } else if (scope === "shared") {
    for (const user of users) {
      if (user.isGM || user.role === 0) continue;
      ownership[user.id] = levels.OWNER;
    }
  } else throw new Error("Unknown notes scope.");
  return ownership;
}

async function ensureFolder() {
  const found = game.folders.find(folder =>
    folder.type === "JournalEntry" && folder.getFlag?.(MODULE_ID, FOLDER_FLAG) === true
  );
  if (found) return found;
  return Folder.implementation.create({
    name: "AFT NPC Notes",
    type: "JournalEntry",
    flags: { [MODULE_ID]: { [FOLDER_FLAG]: true } }
  });
}

export async function ensureJournal(subject, scope, userId, { anonymous = false } = {}) {
  if (!game.user?.isGM) throw new Error("A GM must create NPC note Journals.");
  if (!subject?.actor || !subject.subjectUuid || !isValidScope(scope)) {
    throw new Error("Invalid NPC note request.");
  }
  if (scope === "personal" && !game.users.get(userId)) throw new Error("Unknown player.");
  const key = journalKey(subject.subjectUuid, scope, userId);
  if (inflight.has(key)) return inflight.get(key);
  const work = (async () => {
    const existing = findJournal(game.journal, subject.subjectUuid, scope, userId);
    // Critical: do not modify an existing Journal's permissions or contents.
    if (existing) return existing;
    const folder = await ensureFolder();
    const requester = game.users.get(userId);
    const suffix = subject.subjectUuid.split(".").at(-1).slice(-6);
    const visibleLabel = (anonymous || scope === "shared") ? `NPC ${suffix}` : subject.actor.name;
    const title = scope === "shared"
      ? `${visibleLabel} - Party Notes`
      : `${visibleLabel} - ${requester.name} Notes`;
    const ownership = buildOwnership(subject.actor, scope, userId, game.users, CONST.DOCUMENT_OWNERSHIP_LEVELS);
    const entry = await JournalEntry.implementation.create({
      name: title,
      folder: folder?.id ?? null,
      ownership,
      flags: {
        [MODULE_ID]: {
          [JOURNAL_FLAG]: {
            schema: SCHEMA,
            subjectUuid: subject.subjectUuid,
            scope,
            ...(scope === "personal" ? { userId } : {})
          }
        }
      },
      pages: [{
        name: "Notes",
        type: "text",
        text: { content: "<p></p>", format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML }
      }]
    });
    if (!entry) throw new Error("Foundry did not create the NPC notes Journal.");
    return entry;
  })();
  inflight.set(key, work);
  try { return await work; }
  finally { inflight.delete(key); }
}
